from __future__ import annotations
from configparser import ConfigParser
import getpass
import logging
import mysql.connector
from mysql.connector import Error, MySQLConnection

class DatabaseConnector:
    _instance: DatabaseConnector = None
    def __new__(cls, *args, **kwargs) -> DatabaseConnector:
        if not cls._instance:
            cls._instance = super(DatabaseConnector, cls).__new__(cls)
        return cls._instance

    def __init__(self, host: str, database: str, user: str, password: str, port: int=3306) -> None:
        if not hasattr(self, "initialized"):
            self.host = host
            self.database = database
            self.user = user
            self.password = password
            self.port=port
            self.connection = None
            self.connect() 
            self.initialized = True
            self.waqti_db_reader = None

    def get_instance(self):
        return self.connection
    
    def connect(self) -> None:
        try:
            self.connection = mysql.connector.connect(
                host=self.host,
                database=self.database,
                user=self.user,
                password=self.password,
                port=self.port,
            )
            self.connection._connection_timeout = 300
            self.connection._ssl_active = True

            if self.connection.is_connected():
                logging.info("Connected to the prod database")
        except Error as e:
            logging.error(f"dbconnect Error: {e}")
            raise e

    def disconnect(self) -> None:
        if self.connection and self.connection.is_connected():
            self.connection.close()
            logging.info("Connection closed")