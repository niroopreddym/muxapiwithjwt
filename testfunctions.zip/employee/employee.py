from enum import Enum

class data_sources(Enum):
  name:str='niroop'
