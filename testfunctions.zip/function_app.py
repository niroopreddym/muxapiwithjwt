import azure.functions as func
import datetime
import json
import logging
from configparser import ConfigParser
from database.database_connector import DatabaseConnector
import requests

app = func.FunctionApp()

@app.route(route="collectdata",auth_level=func.AuthLevel.ANONYMOUS)
def collectdata(req: func.HttpRequest) -> func.HttpResponse:
    print("Hello")
    return func.HttpResponse(
                "This HTTP triggered function executed successfully",
                status_code=200
            )


@app.route(route="MyFunction", auth_level=func.AuthLevel.ANONYMOUS)
def MyFunction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
    
@app.route(route="testdb_connection",auth_level=func.AuthLevel.ANONYMOUS)
def testdb_connection(req: func.HttpRequest) -> func.HttpResponse:
    returnObject={
            'status' : 'db connection tested successfully',
            'status_code':200
        }
    logging.info(f'Python HTTP trigger function testodb_connection triggered. {req}')
    
    try:
        config = ConfigParser()
        config.read('config.ini')
        database_host = config.get('MARIADB-AZURE', 'host')
        database_user = config.get('MARIADB-AZURE', 'user')
        database_password = config.get('MARIADB-AZURE', 'password')
        database_name = config.get('MARIADB-AZURE', 'database')
        database_port = config.getint('MARIADB-AZURE', 'port')
        database_ssl_verify_cert = config.getboolean('MARIADB-AZURE', 'ssl_verify_cert')
        db_connector = DatabaseConnector(
            host=database_host,
            database=database_name,
            user=database_user,
            password=database_password,
            port=database_port,
            )
        logging.info(f"db connection tested successfully")
        db_connector.connect()
    except requests.exceptions.RequestException as e:
        logging.info(f"testodb_connection Error occurred: {e}")
        returnObject = {
            'status':f'failed error {e}',
            'status_code':500
        }
    finally:
        return func.HttpResponse(json.dumps(returnObject))
    